describe('Formulario Registrar Tutoría', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/registrar-tutoria.html');
  });

  it('debería enviar la tutoría correctamente', () => {
    cy.intercept('POST', 'http://localhost:8080/guzpasen/anadirTutoria').as('postTutoria');

    cy.get('#motivo').type('Consulta sobre asignatura');
    cy.get('#urgencia').select('Media');
    cy.get('#asignatura').type('Matemáticas');
    cy.get('#alumno-dni').type('12345678A');
    cy.get('#id-usuario').type('3');
    cy.get('#observaciones').type('Necesita apoyo en álgebra.');
    cy.get('#notificar').check();

    cy.get('#form-tutoria').submit();

    cy.wait('@postTutoria').its('request.body').should((body) => {
      expect(body.motivo).to.equal('Consulta sobre asignatura');
      expect(body.urgencia).to.equal('Media');
      expect(body.asignatura).to.equal('Matemáticas');
      expect(body.alumno.dni).to.equal('12345678A');
      expect(body.usuario.idUsuario).to.equal(3);
      expect(body.observaciones).to.equal('Necesita apoyo en álgebra.');
      expect(body.estado).to.equal('PENDIENTE');
      expect(body.acta).to.be.null;
      expect(body.fecha).to.match(/^\d{4}-\d{2}-\d{2}$/);
    });

    cy.on('window:alert', (text) => {
      expect(text).to.contains('Tutoría registrada correctamente.');
    });

    cy.get('#motivo').should('have.value', '');
    cy.get('#urgencia').should('have.value', 'Alta');
    cy.get('#asignatura').should('have.value', '');
    cy.get('#alumno-dni').should('have.value', '');
    cy.get('#id-usuario').should('have.value', '');
    cy.get('#observaciones').should('have.value', '');
    cy.get('#notificar').should('not.be.checked');
  });

  it('debería resetear el formulario al cancelar con confirmación', () => {
    cy.get('#motivo').type('Motivo a borrar');
    cy.get('#cancelar-btn').click();

    cy.on('window:confirm', () => true);

    cy.get('#motivo').should('have.value', '');
  });

  it('debería no resetear el formulario al cancelar y cancelar confirmación', () => {
    cy.get('#motivo').type('Motivo que no se borra');
    cy.get('#cancelar-btn').click();

    cy.on('window:confirm', () => false);

    cy.get('#motivo').should('have.value', 'Motivo que no se borra');
  });
});
