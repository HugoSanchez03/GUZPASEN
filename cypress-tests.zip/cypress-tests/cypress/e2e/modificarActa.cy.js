describe('Modificar Acta', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/modificar-acta.html');
  });

  it('Modifica un acta correctamente', () => {
    cy.intercept('PUT', 'http://localhost:8080/guzpasen/modificarActa', {
      statusCode: 201,
      body: { idActa: 123, puntosTratados: 'Puntos actualizados', observaciones: 'Nuevas observaciones' }
    }).as('modificarActa');

    cy.get('#id-acta').type('11');
    cy.get('#puntos-tratados').type('Puntos actualizados');
    cy.get('#observaciones').type('Nuevas observaciones');

    cy.window().then((win) => {
      cy.stub(win, 'alert').as('alerta');
    });

    cy.get('#form-acta').submit();

    cy.wait('@modificarActa');
    cy.get('@alerta').should('have.been.calledWith', 'Acta modificada correctamente');

    cy.get('#id-acta').should('have.value', '');
    cy.get('#puntos-tratados').should('have.value', '');
    cy.get('#observaciones').should('have.value', '');
  });

  it('Muestra alerta al introducir ID inválido', () => {
    cy.window().then((win) => {
      cy.stub(win, 'alert').as('alerta');
    });

    cy.get('#id-acta').clear();
    cy.get('#form-acta').submit();

    cy.get('@alerta').should('have.been.calledWith', 'Introduce un ID válido');

    cy.get('#id-acta').type('abc');
    cy.get('#form-acta').submit();

    cy.get('@alerta').should('have.been.calledWith', 'El ID debe ser un número válido');
  });

  it('Resetea formulario al pulsar cancelar', () => {
    cy.get('#id-acta').type('456');
    cy.get('#puntos-tratados').type('Puntos previos');
    cy.get('#observaciones').type('Observaciones previas');

    cy.get('#cancelar').click();

    cy.get('#id-acta').should('have.value', '');
    cy.get('#puntos-tratados').should('have.value', '');
    cy.get('#observaciones').should('have.value', '');
  });
});
