describe('Modificar tutoría', () => {
  const url = 'http://127.0.0.1:5500/modificar-tutoria.html';

  beforeEach(() => {
    cy.visit(url);
  });

  it('Debería mostrar error si el ID está vacío', () => {
    cy.get('#motivo').type('Cambio de grupo');
    cy.get('#urgencia').select('Alta');
    cy.get('#asignatura').type('Matemáticas');
    cy.get('#alumno').type('12345678A');
    cy.get('#profesores').type('profesor@iesguzmanes.es');
    cy.get('form').submit();

    cy.on('window:alert', (text) => {
      expect(text).to.contains('Introduce un ID válido');
    });
  });

  it('Debería mostrar error si el ID no es un número', () => {
    cy.get('#idTutoria').type('abc');
    cy.get('#motivo').type('Revisión de examen');
    cy.get('#urgencia').select('Media');
    cy.get('#asignatura').type('Historia');
    cy.get('#alumno').type('87654321B');
    cy.get('#profesores').type('profesor@iesguzmanes.es');
    cy.get('form').submit();

    cy.on('window:alert', (text) => {
      expect(text).to.contains('El ID debe ser un número válido');
    });
  });

  it('Debería enviar el formulario correctamente', () => {
    cy.intercept('PUT', 'http://localhost:8080/guzpasen/modificarTutoria', {
      statusCode: 200,
      body: { mensaje: 'Tutoría modificada correctamente' },
    }).as('modificarTutoria');

    cy.get('#idTutoria').type('123');
    cy.get('#motivo').type('Cambio de aula');
    cy.get('#urgencia').select('Baja');
    cy.get('#asignatura').type('Lengua');
    cy.get('#alumno').type('11223344Z');
    cy.get('#profesores').type('profesor1@ies.com,profesor2@ies.com');
    cy.get('#notificarProfesores').check();

    cy.get('form').submit();

    cy.wait('@modificarTutoria').its('request.body').should((body) => {
      expect(body).to.have.property('idTutoria', 123);
      expect(body).to.have.property('motivo', 'Cambio de aula');
      expect(body).to.have.property('urgencia', 'Baja');
      expect(body).to.have.property('asignatura', 'Lengua');
      expect(body.alumno).to.have.property('dni', '11223344Z');
      expect(body).to.have.property('profesores', 'profesor1@ies.com,profesor2@ies.com');
      expect(body).to.have.property('notificarProfesores', true);
    });

    cy.on('window:alert', (text) => {
      expect(text).to.contains('Tutoría modificada correctamente');
    });
  });

  it('Debería reiniciar el formulario al pulsar cancelar', () => {
    cy.get('#idTutoria').type('55');
    cy.get('#motivo').type('Prueba');
    cy.get('#cancelarBtn').click();
    cy.get('#idTutoria').should('have.value', '');
    cy.get('#motivo').should('have.value', '');
  });

});
