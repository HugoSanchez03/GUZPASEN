describe('Consultar Tutoría', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/consultar-tutoria.html');
  });

  it('Busca una tutoría y muestra los datos correctamente', () => {
    cy.intercept('GET', 'http://localhost:8080/guzpasen/tutoriaPorId/11', {
      statusCode: 200,
      body: {
        motivo: 'Consulta académica',
        urgencia: 'Alta',
        asignatura: 'Matemáticas',
        fecha: '2025-05-22',
        estado: 'Pendiente',
        observaciones: 'Apoyo extra requerido',
        alumno: { nombre: 'Juan Pérez' },
        usuario: { nombre: 'Profesor Gómez' },
        acta: { idActa: 1 }
      }
    }).as('getTutoria');

    cy.window().then(win => {
      cy.stub(win, 'alert').as('alerta');
    });

    cy.get('#tutoria-id').type('123');
    cy.get('#form-consultar-tutoria').submit();

    cy.wait('@getTutoria');

    cy.get('#contenido-tutoria').should('contain.value', 'Motivo: Consulta académica');
    cy.get('#contenido-tutoria').should('contain.value', 'Urgencia: Alta');
    cy.get('#contenido-tutoria').should('contain.value', 'Alumno: Juan Pérez');
    cy.get('#contenido-tutoria').should('contain.value', 'Profesor: Profesor Gómez');
    cy.get('#contenido-tutoria').should('contain.value', 'Acta ID: 10');

    cy.get('@alerta').should('not.have.been.called');
  });

  it('Muestra alerta si el campo ID está vacío al buscar', () => {
    cy.window().then(win => {
      cy.stub(win, 'alert').as('alerta');
    });

    cy.get('#form-consultar-tutoria').submit();

    cy.get('@alerta').should('have.been.calledWith', 'Introduce un ID de tutoría válido.');
  });

  it('Muestra mensaje error si tutoría no encontrada', () => {
    cy.intercept('GET', 'http://localhost:8080/guzpasen/tutoriaPorId/999', {
      statusCode: 404,
      body: {}
    }).as('getTutoria404');

    cy.window().then(win => {
      cy.stub(win, 'alert').as('alerta');
    });

    cy.get('#tutoria-id').type('999');
    cy.get('#form-consultar-tutoria').submit();

    cy.wait('@getTutoria404');

    cy.get('#contenido-tutoria').should('contain.value', 'Tutoría no disponible o error en la consulta.');

  });

  it('Resetea formulario al pulsar Cancelar', () => {
    cy.get('#tutoria-id').type('123');
    cy.get('#contenido-tutoria').type('Texto previo');

    cy.get('#cancelar').click();

    cy.get('#tutoria-id').should('have.value', '');
    cy.get('#contenido-tutoria').should('have.value', '');
  });
});
