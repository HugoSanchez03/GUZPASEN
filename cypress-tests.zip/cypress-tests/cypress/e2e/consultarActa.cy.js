describe('Consultar Acta', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/consultar-acta.html');
  });

  it('Muestra alerta si ID de tutoría está vacío al consultar', () => {
    cy.window().then(win => {
      cy.stub(win, 'alert').as('alertStub');
    });

    cy.get('#consultar').click();

    cy.get('@alertStub').should('have.been.calledWith', 'Introduce un ID de tutoría válido.');
  });

  it('Consulta acta y muestra contenido cuando ID es válido', () => {
    const idValido = '123';
    const actaMock = {
      puntosTratados: 'Punto 1, Punto 2',
      observaciones: 'Sin incidencias',
      fecha: '2025-05-22'
    };

    cy.intercept('GET', `http://localhost:8080/guzpasen/tutoria/${idValido}/acta`, {
      statusCode: 200,
      body: actaMock,
    }).as('getActa');

    cy.get('#id-tutoria').type(idValido);
    cy.get('#consultar').click();

    cy.wait('@getActa');
    cy.get('#contenido-acta').should('contain.value', `Puntos tratados:\n${actaMock.puntosTratados}`);
    cy.get('#contenido-acta').should('contain.value', `Observaciones:\n${actaMock.observaciones}`);
    cy.get('#contenido-acta').should('contain.value', `Fecha: ${actaMock.fecha}`);
  });

  it('Muestra mensaje de error si la consulta falla', () => {
    const idNoExiste = '999';

    cy.intercept('GET', `http://localhost:8080/guzpasen/tutoria/${idNoExiste}/acta`, {
      statusCode: 404,
      body: {},
    }).as('getActa404');

    cy.get('#id-tutoria').type(idNoExiste);
    cy.get('#consultar').click();

    cy.wait('@getActa404');

    cy.get('#contenido-acta').should('have.value', 'Acta no disponible o error en la consulta.');
  });

  it('Al pulsar cancelar se limpia el formulario y textarea', () => {
    cy.get('#id-tutoria').type('123');
    cy.get('#contenido-acta').invoke('val', 'Texto de prueba');
    
    cy.get('#cancelar').click();

    cy.get('#id-tutoria').should('have.value', '');
    cy.get('#contenido-acta').should('have.value', '');
  });
});
