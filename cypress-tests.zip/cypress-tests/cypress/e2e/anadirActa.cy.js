describe('Añadir Acta', () => {
  beforeEach(() => {
    cy.visit('http://127.0.0.1:5500/alta-acta.html');
  });

  it('debe permitir enviar el formulario y mostrar alerta de éxito', () => {

    cy.intercept('POST', 'http://localhost:8080/guzpasen/anadirActa').as('postActa');

    cy.get('#puntos-tratados').type('Punto tratado de prueba');
    cy.get('#observaciones').type('Observaciones de prueba');

    cy.get('#btn-aceptar').click();

    cy.wait('@postActa');

    cy.on('window:alert', (txt) => {
      expect(txt).to.contains('Acta añadida correctamente');
    });
  });

  it('debe limpiar el formulario si se confirma cancelar', () => {
    cy.get('#puntos-tratados').type('Texto temporal');
    cy.get('#observaciones').type('Texto temporal');

    cy.on('window:confirm', () => true);

    cy.get('#btn-cancelar').click();

    cy.get('#puntos-tratados').should('have.value', '');
    cy.get('#observaciones').should('have.value', '');
  });

  it('no debe limpiar el formulario si se cancela la confirmación', () => {
    cy.get('#puntos-tratados').type('Texto temporal');
    cy.get('#observaciones').type('Texto temporal');

    cy.on('window:confirm', () => false);

    cy.get('#btn-cancelar').click();

    cy.get('#puntos-tratados').should('have.value', 'Texto temporal');
    cy.get('#observaciones').should('have.value', 'Texto temporal');
  });
});
