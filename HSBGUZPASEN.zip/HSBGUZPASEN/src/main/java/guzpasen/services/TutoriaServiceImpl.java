package guzpasen.services;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import guzpasen.exceptions.TutoriaNotFoundException;
import guzpasen.models.Tutoria;
import guzpasen.models.Tutoria.Estado;
import guzpasen.repositories.TutoriaRepository;

@Service
public class TutoriaServiceImpl implements TutoriaService {
	
	@Autowired
	private TutoriaRepository tutoriaRepository;
	
	@Override
	public Tutoria createTutoria(Tutoria tutoria) {
		return tutoriaRepository.save(tutoria);
	}

	@Override
	public Tutoria deleteTutoria(Tutoria tutoria) {
		tutoriaRepository.delete(tutoria);
		return tutoria;
		
	}

	@Override
	public List<Tutoria> findAll() {
		return tutoriaRepository.findAll();
	}

	@Override
	public Optional<Tutoria> findByIdTutoria(Long idTutoria) {
		return tutoriaRepository.findByIdTutoria(idTutoria);
	}

	@Override
	public List<Tutoria> findByEstado(Estado estado) {
		return tutoriaRepository.findByEstado(estado);
	}

	@Override
	public List<Tutoria> findByFecha(LocalDate fecha) {
		return tutoriaRepository.findByFecha(fecha);
	}

	@Override
	public List<Tutoria> findByAsignatura(String asignatura) {
		return tutoriaRepository.findByAsignatura(asignatura);
	}

	@Override
	public Tutoria updateTutoria(Tutoria tutoria) {
		Tutoria tutoriaEncontrada = tutoriaRepository.findById(tutoria.getIdTutoria()).orElseThrow( 
				() -> new TutoriaNotFoundException(tutoria.getIdTutoria()));

		tutoriaEncontrada.setMotivo(tutoria.getMotivo());
		tutoriaEncontrada.setUrgencia(tutoria.getUrgencia());
		tutoriaEncontrada.setAsignatura(tutoria.getAsignatura());
		tutoriaEncontrada.setFecha(tutoria.getFecha());
		tutoriaEncontrada.setEstado(tutoria.getEstado());
		tutoriaEncontrada.setObservaciones(tutoria.getObservaciones());
		tutoriaEncontrada.setUsuario(tutoria.getUsuario());
		tutoriaEncontrada.setAlumno(tutoria.getAlumno());
		tutoriaEncontrada.setActa(tutoria.getActa());
		
		return tutoriaRepository.save(tutoriaEncontrada);
		
	}

}
