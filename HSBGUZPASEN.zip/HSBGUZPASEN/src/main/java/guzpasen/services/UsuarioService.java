package guzpasen.services;

import guzpasen.models.Usuario;

public interface UsuarioService {
	
	public Usuario createUsuario(Usuario usuario);
	
}
