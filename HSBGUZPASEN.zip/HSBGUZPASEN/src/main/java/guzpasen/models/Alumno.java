package guzpasen.models;

import jakarta.persistence.*;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Entity(name = "alumno")
public class Alumno {

    @Id
    @Column(name = "dni")
    private String dni;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "apellidos")
    private String apellidos;

    @Column(name = "nombre_tutor_legal")
    private String nombreTutorLegal;

    @Column(name = "apellidos_tutor_legal")
    private String apellidosTutorLegal;

    @Column(name = "email_tutor_legal")
    private String emailTutorLegal;
}
