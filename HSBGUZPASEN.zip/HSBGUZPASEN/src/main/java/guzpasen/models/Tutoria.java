package guzpasen.models;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Entity(name = "tutoria")
public class Tutoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tutoria")
    private Long idTutoria;

    @Column(name = "motivo")
    private String motivo;

    @Column(name = "urgencia")
    private String urgencia;

    @Column(name = "asignatura")
    private String asignatura;

    @Column(name = "fecha")
    private LocalDate fecha;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado")
    private Estado estado;

    @Column(name = "observaciones")
    private String observaciones;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @ManyToOne
    @JoinColumn(name = "dni_alumno")
    private Alumno alumno;

    @ManyToOne
    @JoinColumn(name = "id_acta")
    private Acta acta;

    public enum Estado {
        PENDIENTE,
        REALIZADA
    }
}
