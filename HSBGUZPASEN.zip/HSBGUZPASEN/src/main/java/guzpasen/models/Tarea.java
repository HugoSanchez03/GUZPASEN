package guzpasen.models;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Entity(name = "tarea")
public class Tarea {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tarea")
    private Long idTarea;

    @Column(name = "asignatura")
    private String asignatura;

    @Column(name = "descripcion")
    private String descripcion;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado")
    private Estado estado;

    @Column(name = "fecha_tarea")
    private LocalDate fechaTarea;

    @ManyToOne
    @JoinColumn(name = "id_tutoria")
    private Tutoria tutoria;

    public enum Estado {
        COMPLETADA,
        PENDIENTE
    }
}
