package guzpasen.models;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Entity(name = "acta")
public class Acta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_acta")
    private Long idActa;

    @Column(name = "puntos_tratados")
    private String puntosTratados;

    @Column(name = "observaciones")
    private String observaciones;

    @Column(name = "fecha")
    private LocalDate fecha;
}
