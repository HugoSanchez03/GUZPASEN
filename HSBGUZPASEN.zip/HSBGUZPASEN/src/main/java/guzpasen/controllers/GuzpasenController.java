package guzpasen.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import guzpasen.exceptions.ActaNotFoundException;
import guzpasen.exceptions.AlumnoNotFoundException;
import guzpasen.exceptions.TareaNotFoundException;
import guzpasen.exceptions.TutoriaNotFoundException;
import guzpasen.models.Acta;
import guzpasen.models.Alumno;
import guzpasen.models.Tarea;
import guzpasen.models.Tutoria;
import guzpasen.models.Usuario;
import guzpasen.services.ActaService;
import guzpasen.services.AlumnoService;
import guzpasen.services.TareaService;
import guzpasen.services.TutoriaService;
import guzpasen.services.UsuarioService;

@RestController
@RequestMapping("/guzpasen")
public class GuzpasenController {
	
	@Autowired
	private ActaService actaService;
	
	@Autowired
	private AlumnoService alumnoService;
	
	@Autowired
	private TareaService tareaService;
	
	@Autowired
	private TutoriaService tutoriaService;
	
	@Autowired
	private UsuarioService usuarioService;
	
	// SERVICIOS CREATE
	@PostMapping("/anadirActa")
	public ResponseEntity<Acta> addActa(@RequestBody Acta acta) {
		Acta actaAnadida = actaService.createActa(acta);
		return new ResponseEntity<>(actaAnadida, HttpStatus.CREATED);
	}
	
	@PostMapping("/anadirAlumno")
	public ResponseEntity<Alumno> addAlumno(@RequestBody Alumno alumno) {
		Alumno alumnoAnadida = alumnoService.createAlumno(alumno);
		return new ResponseEntity<>(alumnoAnadida, HttpStatus.CREATED);
	}
	
	@PostMapping("/anadirTutoria")
	public ResponseEntity<Tutoria> addTutoria(@RequestBody Tutoria tutoria) {
		Tutoria tutoriaAnadida = tutoriaService.createTutoria(tutoria);
		return new ResponseEntity<>(tutoriaAnadida, HttpStatus.CREATED);
	}
	
	@PostMapping("/anadirTarea")
	public ResponseEntity<Tarea> addTarea(@RequestBody Tarea tarea) {
		Tarea tareaAnadida = tareaService.createTarea(tarea);
		return new ResponseEntity<>(tareaAnadida, HttpStatus.CREATED);
	}
	
	@PostMapping("/anadirUsuario")
	public ResponseEntity<Usuario> addUsuario(@RequestBody Usuario usuario) {
		Usuario usuarioAnadido = usuarioService.createUsuario(usuario);
		return new ResponseEntity<>(usuarioAnadido, HttpStatus.CREATED);
	}
	
	// SERVICIOS DELETE
	@DeleteMapping("/eliminarActa")
	public ResponseEntity<Acta> deleteActa(@RequestBody Acta acta) {
		Acta actaEliminado = actaService.deleteActa(acta);
		return new ResponseEntity<>(actaEliminado, HttpStatus.OK);
	}
	
	@DeleteMapping("/eliminarAlumno")
	public ResponseEntity<Alumno> deleteAlumno(@RequestBody Alumno alumno) {
		Alumno alumnoEliminado = alumnoService.deleteAlumno(alumno);
		return new ResponseEntity<>(alumnoEliminado, HttpStatus.OK);
	}
	
	@DeleteMapping("/eliminarTutoria")
	public ResponseEntity<Tutoria> deleteTutoria(@RequestBody Tutoria tutoria) {
		Tutoria tutoriaEliminada = tutoriaService.deleteTutoria(tutoria);
		return new ResponseEntity<>(tutoriaEliminada, HttpStatus.OK);
	}
	
	@DeleteMapping("/eliminarTarea")
	public ResponseEntity<Tarea> deleteTarea(@RequestBody Tarea tarea) {
		Tarea tareaEliminada = tareaService.deleteTarea(tarea);
		return new ResponseEntity<>(tareaEliminada, HttpStatus.OK);
	}
	
	// SERVICIOS DE CONSULTA
	@RequestMapping("/listarActas")
    public List<Acta> catalogActa(Model model) {
        List<Acta> actas = actaService.findAll();
        model.addAttribute("actas", actas);
        return actas;
    }
	
	@GetMapping("/actaPorId/{id}")
	public Acta getActaById(@PathVariable Long id, Model model) {
	    Acta acta = actaService.findByIdActa(id)
	            .orElseThrow(() -> new ActaNotFoundException(id));
	    model.addAttribute("acta", acta);
	    return acta;
	}
	
	// TODO FILTROS POR FECHA
	
	@RequestMapping("/listarAlumnos")
    public List<Alumno> catalogAlumno(Model model) {
        List<Alumno> alumnos = alumnoService.findAll();
        model.addAttribute("alumnos", alumnos);
        return alumnos;
    }
	
	@GetMapping("/alumnoPorDni/{dni}")
	public Alumno getAlumnoByDni(@PathVariable String dni, Model model) {
	    Alumno alumno = alumnoService.findByDni(dni)
	            .orElseThrow(() -> new AlumnoNotFoundException(dni));
	    model.addAttribute("alumno", alumno);
	    return alumno;
	}
	
	@RequestMapping("/listarTutorias")
    public List<Tutoria> catalogTutorias(Model model) {
        List<Tutoria> tutorias = tutoriaService.findAll();
        model.addAttribute("tutorias", tutorias);
        return tutorias;
    }
	
	@GetMapping("/tutoriaPorId/{id_tutoria}")
	public Tutoria getTutoriaById(@PathVariable Long id_tutoria, Model model) {
		Tutoria tutoria = tutoriaService.findByIdTutoria(id_tutoria)
	            .orElseThrow(() -> new TutoriaNotFoundException(id_tutoria));
	    model.addAttribute("tutoria", tutoria);
	    return tutoria;
	}
	
	@RequestMapping("/listarTareas")
    public List<Tarea> catalogTareas(Model model) {
        List<Tarea> tareas = tareaService.findAll();
        model.addAttribute("tareas", tareas);
        return tareas;
    }
	
	@GetMapping("/tareaPorId/{id_tarea}")
	public Tarea getTareaById(@PathVariable Long id_tarea, Model model) {
		Tarea tarea = tareaService.findByIdTarea(id_tarea)
	            .orElseThrow(() -> new TareaNotFoundException(id_tarea));
	    model.addAttribute("tutoria", tarea);
	    return tarea;
	}
	
	// SERVICIOS DE UPDATE
	@PutMapping("/modificarActa")
	public ResponseEntity<Acta> updateActa(@RequestBody Acta acta) {
		return new ResponseEntity<>(actaService.updateActa(acta), HttpStatus.CREATED);
	}
	
	@PutMapping("/modificarAlumno")
	public ResponseEntity<Alumno> updateAlumno(@RequestBody Alumno alumno) {
		return new ResponseEntity<>(alumnoService.updateAlumno(alumno), HttpStatus.CREATED);
	}
	
	@PutMapping("/modificarTarea")
	public ResponseEntity<Tarea> updateTarea(@RequestBody Tarea tarea) {
		return new ResponseEntity<>(tareaService.updateTarea(tarea), HttpStatus.CREATED);
	}
	
	@PutMapping("/modificarTutoria")
	public ResponseEntity<Tutoria> updateTutoria(@RequestBody Tutoria tutoria) {
		return new ResponseEntity<>(tutoriaService.updateTutoria(tutoria), HttpStatus.CREATED);
	}
	
	
	// TODO SERVICIOS USUARIO

	

}
